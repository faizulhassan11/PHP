<?php

require_once('require/database_settings.php');
require_once('require/database_class.php');

$driver = new mysqli_driver();
$driver->report_mode = MYSQLI_REPORT_OFF;

$bank = new Bank(HOST_NAME, USER_NAME, PASSWORD, DATABASE);

if(isset($_POST['register'])){
    $result = $bank->register($_POST['first_name'],$_POST['last_name'],$_POST['email'],$_POST['number'],$_POST['password']);

    if($result){
        echo "<p style='color: green'>Account Created Successfully!...</p>";
        header("Location:login.php");
    }
    else{
       
        echo "<p style='color: red'>Account Creation failed!...</p>";    
     ?>
<a href="register.php">Back</a>
<?php    
}
}



?>