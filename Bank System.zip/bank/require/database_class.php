<?php
	class Bank
	{
		public $host_name	=	NULL;
		public $user_name	= 	NULL;
		public $password	= 	NULL;
		public $database	= 	NULL;
		public $connection	=	NULL;
		public $query 		= 	NULL;
		public $result		= 	NULL;

	

		public function __construct($host_name, $user_name, $password, $database)
		{
			$this->host_name	=	$host_name;
			$this->user_name	= 	$user_name;
			$this->password 	= 	$password;
			$this->database 	= 	$database;

			$this->connection = mysqli_connect($this->host_name, $this->user_name, $this->password, $this->database);
		
			if(mysqli_connect_errno())
			{
				echo "<p><span style='color: red'>Database Connection Problem!...</span> Error No: ".mysqli_connect_errno()." Error Message: ".mysqli_connect_error()."</p>";
			}
		}

	    public function register($first_name, $last_name, $email, $number, $password){
			$account_number = floor(rand(1000,10000000));
			$this->query = "INSERT INTO user (first_name, last_name, email, number, account_number, password) VALUES ('$first_name', '$last_name', '$email', '$number', '$account_number', '$password')";
			$this->result = mysqli_query($this->connection, $this->query);
			return $this->result;
		}

		public function login($email, $password){
			$this->query = "SELECT * FROM user WHERE email = '$email' AND password = '$password'";
			$this->result = mysqli_query($this->connection, $this->query);
		
			if(mysqli_num_rows($this->result) > 0){
				return $this->result;
			} else {
				return $this->result = false;
			}
		}
		

		public function deposit($bank_account_number, $amount){
			if($amount > 0){
				$this->query = "UPDATE user SET balance = balance + $amount WHERE account_number = $bank_account_number";
				$this->result = mysqli_query($this->connection, $this->query);
				return $this->result;
			} else {
				return $this->result = false;
			}
		}
		

		public function withdraw($bank_account_number, $amount){
			$this->query = "SELECT * FROM user WHERE account_number = $bank_account_number";
			$this->result = mysqli_query($this->connection, $this->query);
			$user = mysqli_fetch_assoc($this->result);
		
			if($user['balance'] >= $amount AND $amount > 0){
				$this->query = "UPDATE user SET balance = balance - $amount WHERE account_number = $bank_account_number";
				$this->result = mysqli_query($this->connection, $this->query);
				
				return $this->result;
			} else {
			
				return $this->result = false;
			}
		}
		

		public function show_user_account_information($bank_account_number){
			$this->query = "SELECT * FROM user WHERE account_number = $bank_account_number";
			$this->result = mysqli_query($this->connection, $this->query);
			return $this->result;
		}

	public function change_password($account_number, $old_password, $new_password){
        $this->query = "SELECT * FROM user WHERE account_number = $account_number AND password = '$old_password'";
        $this->result = mysqli_query($this->connection, $this->query);

        if(mysqli_num_rows($this->result) > 0){
            $this->query = "UPDATE user SET password = '$new_password' WHERE account_number = $account_number";
            $this->result = mysqli_query($this->connection, $this->query);
            return true;
        } else {
            return false;
        }
    }

		public function __destruct()
		{
			mysqli_close($this->connection);
		}


	}



  
?>