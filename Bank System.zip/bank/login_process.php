<!DOCTYPE html>
<html>

<head>
    <title>ATM</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
    }

    .container {
        width: 400px;
        margin: 0 auto;
        padding: 20px;
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
        text-align: center;
        margin-bottom: 20px;
    }

    p {
        margin-bottom: 10px;
    }

    a {
        display: block;
        width: 100%;
        padding: 10px;
        background-color: #45a049;
        color: #fff;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        text-decoration: none;
        text-align: center;
        margin-bottom: 10px;
    }
    </style>
</head>

<body>


    <?php
session_start();
require_once('require/database_settings.php');
require_once('require/database_class.php');

$driver = new mysqli_driver();
$driver->report_mode = MYSQLI_REPORT_OFF;

$bank = new Bank(HOST_NAME, USER_NAME, PASSWORD, DATABASE);

if(isset($_POST['login'])){
    $result = $bank->login($_POST['email'],$_POST['password']);



    if($result){
        echo "<p style='color: green'>Login Successfully!...</p>";

     
        while($row = mysqli_fetch_assoc($result)){

        $_SESSION['user'] = $row;

     ?>

    <div class="container">

        <h1>Welcome, <?= $row['first_name']." ".$row['last_name']?></h1>
        <p><strong>Account Number:</strong> <?= $row['account_number']?></p>
        <p><strong>Name:</strong> <?= $row['first_name']." ".$row['last_name']?></p>
        <p><strong>Phone Number:</strong> <?= $row['number']?></p>
        <p><strong>Email:</strong> <?= $row['email']?></p>
        <a href="withdraw.php">Withdraw</a>
        <a href="deposit.php">Deposit</a>
        <a href="check_balance.php">Check Balance</a>
        <a href="change_password.php">Change Password</a>
    </div>

    <?php

        }

    }else{
      
        echo "<p style='color: red'>Not Have an account!...</p>";
        ?>
    <a href="login.php">Back</a>
    <?php
        
    }
}


?>


</body>

</html>