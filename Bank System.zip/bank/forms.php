<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAIZ BANK</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
    }

    .container {
        width: 300px;
        margin: 0 auto;
        padding: 20px 40px;
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
        text-align: center;
        margin-bottom: 20px;
    }

    input[type="text"],
    input[type="email"],
    input[type="password"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 16px;
    }

    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        padding: 10px;
        cursor: pointer;
        width: 100%;
        margin-bottom: 10px;
    }

    input[type="submit"]:hover {
        background-color: #45a049;
    }

    p {
        text-align: center;
        margin-top: 20px;
        font-size: 16px;
    }

    a {
        color: #4CAF50;
        text-decoration: none;
    }

    a:hover {
        text-decoration: underline;
    }
    </style>
</head>

<body>


    <?php

class Forms{



public function registerForm() { ?>


    <div class="container">
        <h1>Create An Account</h1>
        <form action="register_process.php" method="POST">
            <input type="text" name="first_name" placeholder="First Name" required>
            <input type="text" name="last_name" placeholder="Last Name" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="number" placeholder="Phone Number" required>
            <input type="password" name="password" placeholder="Password In Numbers" required>
            <input type="submit" name="register" value="Register">
        </form>
        <p>Already have an account? <a href="login.php">Login</a></p>
    </div>



    <?php
    }

    public function loginForm(){ ?>

    <div class="container">
        <h1>Login</h1>
        <form action="login_process.php" method="POST">

            <input type="email" name="email" placeholder="Enter Your Email" required />
            <input type="password" name="password" placeholder="Enter Your Password In Numbers" required />
            <input type="submit" value="Login" name="login" />
            <span>Don't have an account?<a href="register.php">Register</a></span>
        </form>
    </div>

    <?php
    }

    public function depositForm(){ ?>



    <div class="container">
        <h1>Deposit</h1>
        <form action="deposit_process.php" method="post">

            <input type="text" name="amount" placeholder="Enter Amount" required>

            <input type="submit" name="deposit" id="deposit" value="Deposit">

            <span><a href="login_process.php">Back</a></span>



        </form>

    </div>



    <?php
        }

        public function withdrawForm(){ ?>



    <div class="container">
        <h1>Withdraw</h1>
        <form action="withdraw_process.php" method="post">

            <input type="text" name="amount" placeholder="Enter Amount" required>

            <input type="submit" name="deposit" id="deposit" value="Withdraw">
            <span><a href="login.php">Back</a></span>
        </form>
    </div>



    <?php
      }


     public function changePasswordForm(){ ?>

    <div class="container">
        <h1>Change Password</h1>
        <form action="change_password_process.php" method="post">

            <input type="password" name="old_password" placeholder="Enter Old Password" required>
            <input type="password" name="new_password" placeholder="Enter New Password" required>

            <input type="submit" name="change_password" id="change_password" value="Change">
            <span><a href="login.php">Back</a></span>
        </form>
    </div>



    <?php
    }
}
    ?>


</body>

</html>